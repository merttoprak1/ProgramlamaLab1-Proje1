**************MİNİMUM KAPSAYAN ÇEMBER PROBLEMİ**************


Bu program kullanıcıdan alınan noktaları kapsayan en küçük yarı çaplı çemberi bulmak içindir.

**************Kullanım**************

Noktaları girmek için points.txt dosyasını açın.
Noktaların koordinat değerlerini x y şeklinde arasında bir boşluk olacak şekilde yazın. Örnek:

sayi1xdeğeri sayi1ydeğeri
sayi2xdeğeri sayi2ydeğeri

şeklinde yazabilirsiniz.
İyi Çalışmalar.